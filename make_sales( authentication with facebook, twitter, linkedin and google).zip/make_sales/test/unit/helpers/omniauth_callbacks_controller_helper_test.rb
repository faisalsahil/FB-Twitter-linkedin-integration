require 'test_helper'

class OmniauthCallbacksControllerHelperTest < ActionView::TestCase
end
