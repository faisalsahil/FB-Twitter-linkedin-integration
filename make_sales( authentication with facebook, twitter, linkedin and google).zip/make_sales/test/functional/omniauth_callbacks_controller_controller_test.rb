require 'test_helper'

class OmniauthCallbacksControllerControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
